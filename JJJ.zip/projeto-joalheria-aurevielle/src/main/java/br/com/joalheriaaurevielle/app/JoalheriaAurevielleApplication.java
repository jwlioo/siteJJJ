package br.com.joalheriaaurevielle.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoalheriaAurevielleApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoalheriaAurevielleApplication.class, args);
	}

}
